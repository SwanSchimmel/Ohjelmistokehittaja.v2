﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Pizza_ordering_system
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // PIZZA TYPES
            comboBoxPizza.Items.Add("Pepperoni");
            comboBoxPizza.Items.Add("Hawaii");
            comboBoxPizza.Items.Add("BBQ Chicken");

            // SIZES
            comboBoxSize.Items.Add("Small");
            comboBoxSize.Items.Add("Medium");
            comboBoxSize.Items.Add("Large");

            // TOPPINGS
            checkedListBoxToppings.Items.Add("Extra Cheese");
            checkedListBoxToppings.Items.Add("Mushrooms");
            checkedListBoxToppings.Items.Add("Olives");
        }

        private void buttonAddToCart_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(comboBoxPizza.Text) || string.IsNullOrEmpty(comboBoxSize.Text))
            {
                MessageBox.Show("Выберите пиццу и размер!");
                return;
            }

            string toppings = "";
            foreach (var item in checkedListBoxToppings.CheckedItems)
            {
                if (toppings != "") toppings += ", ";
                toppings += item.ToString();
            }
            if (string.IsNullOrEmpty(toppings)) toppings = "Без добавок";

            double price = CalculatePrice(/*...*/); // оставь свою функцию

            // Добавляем строку в DataTable
            Cart.Items.Rows.Add(
                comboBoxPizza.Text,
                comboBoxSize.Text,
                (int)numericUpDownQty.Value,
                toppings,
                price
            );

            MessageBox.Show("Пицца добавлена в корзину!");
        }

        private double CalculatePrice(Pizza pizza)
        {
            double price = 0;

            if (pizza.Size == "Small") price = 8;
            else if (pizza.Size == "Medium") price = 10;
            else if (pizza.Size == "Large") price = 12;

            price += pizza.Toppings.Count * 1.5;
            price *= pizza.Quantity;

            return price;
        }
    }
}