﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Pizza_ordering_system
{
    public partial class PaymentForm : Form
    {
        private List<Pizza> cartItems;
        Customer customer = new Customer();

        public PaymentForm(List<Pizza> cart)
        {
            InitializeComponent();
            cartItems = cart;
        }

        private void buttonPay_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBoxFirstName.Text) ||
                string.IsNullOrWhiteSpace(textBoxLastName.Text) ||
                string.IsNullOrWhiteSpace(textBoxAddress.Text))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля!", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cartItems.Count == 0)
            {
                MessageBox.Show("Корзина пуста!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            customer.FirstName = textBoxFirstName.Text.Trim();
            customer.LastName = textBoxLastName.Text.Trim();
            customer.Address = textBoxAddress.Text.Trim();
            customer.Phone = "";   // можно добавить TextBox позже
            customer.Email = "";
            customer.PaymentMethod = comboBoxPayment.Text;

            Order order = new Order();

            if (order.SaveOrder(customer, cartItems))
            {
                MessageBox.Show("Заказ успешно оформлен!\nСпасибо за покупку!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                cartItems.Clear(); // очищаем корзину

                ConfirmForm confirmForm = new ConfirmForm();
                confirmForm.Show();
                this.Close();
            }
        }
    }
}   