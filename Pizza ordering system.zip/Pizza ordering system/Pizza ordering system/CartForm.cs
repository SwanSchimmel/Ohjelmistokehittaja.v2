﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;



namespace Pizza_ordering_system
{
    public partial class CartForm : Form
    {
        private List<Pizza> cartItems;

        public CartForm(List<Pizza> cart)
        {
            InitializeComponent();
            cartItems = cart;
        }

        private void CartForm_Load(object sender, EventArgs e)
        {
            LoadCart();
        }

        private void LoadCart()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Пицца", typeof(string));
            dt.Columns.Add("Размер", typeof(string));
            dt.Columns.Add("Кол-во", typeof(int));
            dt.Columns.Add("Добавки", typeof(string));
            dt.Columns.Add("Цена", typeof(double));

            foreach (var pizza in cartItems)
            {
                string toppings = pizza.Toppings.Count > 0
                    ? string.Join(", ", pizza.Toppings)
                    : "Без добавок";

                dt.Rows.Add(pizza.Name, pizza.Size, pizza.Quantity, toppings, pizza.Price);
            }

            dataGridViewCart.DataSource = dt;
            dataGridViewCart.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCart.Columns["Цена"].DefaultCellStyle.Format = "0.00 ₽";
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            if (dataGridViewCart.CurrentRow == null) return;

            int index = dataGridViewCart.CurrentRow.Index;
            if (index >= 0 && index < cartItems.Count)
            {
                cartItems.RemoveAt(index);
                LoadCart();
            }
        }

        private void buttonCheckout_Click(object sender, EventArgs e)
        {
            if (cartItems.Count == 0)
            {
                MessageBox.Show("Корзина пуста!");
                return;
            }

            PaymentForm paymentForm = new PaymentForm(cartItems);
            paymentForm.Show();
            this.Hide();
        }
    }
}