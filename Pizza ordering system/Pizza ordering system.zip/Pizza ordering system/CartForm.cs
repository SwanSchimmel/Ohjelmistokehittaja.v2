﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;

namespace Pizza_ordering_system
{
    using System;
    using System.Data;
    using System.Windows.Forms;

    namespace Pizza_ordering_system
    {
        public partial class CartForm : Form
        {
            private object dataGridViewCart;

            public CartForm()
            {
                InitializeComponent();
            }

            private void InitializeComponent()
            {
                throw new NotImplementedException();
            }

            private void LoadCart()
            {
                dataGridViewCart.DataSource = null;
                dataGridViewCart.DataSource = Cart.Items;
            }

            private void CartForm_Load(object sender, EventArgs e)
            {
                LoadCart();
            }

            private void buttonRemove_Click(object sender, EventArgs e)
            {
                if (dataGridViewCart.CurrentRow ==  null)
                {
                    return;
                }
                int index = dataGridViewCart.CurrentRow.Index;

                if (index >= 0 && index < Cart.Items.Count)
                {
                    Cart.Items.RemoveAt(index);
                    LoadCart();
                }
            }

            private void buttonCheckout_Click(object sender, EventArgs e)
            {
                PaymentForm paymentForm = new PaymentForm();
                paymentForm.Show();
                this.Hide();
            }
        }
    }
}   
