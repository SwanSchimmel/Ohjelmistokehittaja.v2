﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Pizza_ordering_system
{
    internal class CONNECT
    {
        private MySqlConnection connection =
            new MySqlConnection(
                "server=localhost;" +
                "port=3306;" +
                "username=root;" +
                "password=;" +
                "database=pizza_db"
            );

        public MySqlConnection getConnection()
        {
            return connection;
        }

        public void openConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public void closeConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }
}
