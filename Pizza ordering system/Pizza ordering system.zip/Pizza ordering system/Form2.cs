﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_ordering_system
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // PIZZA TYPES
            comboBoxPizza.Items.Add("Pepperoni");
            comboBoxPizza.Items.Add("Hawaii");
            comboBoxPizza.Items.Add("BBQ Chicken");

            // SIZES
            comboBoxSize.Items.Add("Small");
            comboBoxSize.Items.Add("Medium");
            comboBoxSize.Items.Add("Large");

            // TOPPINGS
            checkedListBoxToppings.Items.Add("Extra Cheese");
            checkedListBoxToppings.Items.Add("Mushrooms");
            checkedListBoxToppings.Items.Add("Olives");
        }


        private void buttonAddToCart_Click(object sender, EventArgs e)
        {
            Pizza pizza = new Pizza();

            pizza.Name = comboBoxPizza.Text;

            pizza.Size = comboBoxSize.Text;

            pizza.Quantity = Convert.ToInt32(numericUpDownQty.Value);

            pizza.Toppings = new List<string>();

            foreach (var item in checkedListBoxToppings.CheckedItems)
            {
                pizza.Toppings.Add(item.ToString());
            }

            pizza.Price = CalculatePrice(pizza);

            Cart.cartItems.Add(pizza);

            MessageBox.Show("Pizza Added To Cart");
        }

        private double CalculatePrice(Pizza pizza)
        {
            double price = 0;

            // BASE PRICE
            if (pizza.Size == "Small")
            {
                price = 8;
            }
            else if (pizza.Size == "Medium")
            {
                price = 10;
            }
            else if (pizza.Size == "Large")
            {
                price = 12;
            }

            // TOPPINGS
            price += pizza.Toppings.Count * 1.5;

            // QUANTITY
            price *= pizza.Quantity;

            return price;
        }
    }
}
