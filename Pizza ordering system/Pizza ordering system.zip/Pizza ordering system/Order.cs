﻿using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_ordering_system
{
    namespace Pizza_ordering_system
    {
        internal class Order
        {
            CONNECT connect = new CONNECT();

            public bool SaveOrder(Customer customer, string paymentMethod)
            {
                try
                {
                    connect.openConnection();

                    // CUSTOMER
                    MySqlCommand customerCommand = new MySqlCommand();
                    customerCommand.Connection = connect.getConnection();

                    customerCommand.CommandText =
                    "INSERT INTO customers(first_name,last_name,address,phone,email) " +
                    "VALUES(@fn,@ln,@ad,@ph,@em)";

                    customerCommand.Parameters.Add("@fn", MySqlDbType.VarChar).Value = customer.FirstName;
                    customerCommand.Parameters.Add("@ln", MySqlDbType.VarChar).Value = customer.LastName;
                    customerCommand.Parameters.Add("@ad", MySqlDbType.VarChar).Value = customer.Address;
                    customerCommand.Parameters.Add("@ph", MySqlDbType.VarChar).Value = customer.Phone;
                    customerCommand.Parameters.Add("@em", MySqlDbType.VarChar).Value = customer.Email;

                    customerCommand.ExecuteNonQuery();

                    int customerID = Convert.ToInt32(customerCommand.LastInsertedId);

                    // TOTAL PRICE
                    double totalPrice = 0;

                    foreach (Pizza p in Cart.Items)
                        totalPrice += p.Price;

                    // ORDER
                    MySqlCommand orderCommand = new MySqlCommand();
                    orderCommand.Connection = connect.getConnection();

                    orderCommand.CommandText =
                    "INSERT INTO orders(customer_id,total_price,payment_method,order_date) " +
                    "VALUES(@cid,@tp,@pm,@od)";

                    orderCommand.Parameters.Add("@cid", MySqlDbType.Int32).Value = customerID;
                    orderCommand.Parameters.Add("@tp", MySqlDbType.Double).Value = totalPrice;
                    orderCommand.Parameters.Add("@pm", MySqlDbType.VarChar).Value = paymentMethod;
                    orderCommand.Parameters.Add("@od", MySqlDbType.DateTime).Value = DateTime.Now;

                    orderCommand.ExecuteNonQuery();

                    int orderID = Convert.ToInt32(orderCommand.LastInsertedId);

                    // ORDER ITEMS
                    foreach (Pizza pizza in Cart.Items)
                    {
                        MySqlCommand itemCommand = new MySqlCommand();
                        itemCommand.Connection = connect.getConnection();

                        itemCommand.CommandText =
                        "INSERT INTO order_items(`order_id`,`pizza_name`,`pizza_size`,`toppings`,`quantity`,`item_price`) VALUES(@oid,@pn,@ps,@tp,@qt,@pr)";

                        itemCommand.Parameters.Add("@oid", MySqlDbType.Int32).Value = orderID;
                        itemCommand.Parameters.Add("@pn", MySqlDbType.VarChar).Value = pizza.Name;
                        itemCommand.Parameters.Add("@ps", MySqlDbType.VarChar).Value = pizza.Size;
                        itemCommand.Parameters.Add("@tp", MySqlDbType.Text).Value = string.Join(",", pizza.Toppings);
                        itemCommand.Parameters.Add("@qt", MySqlDbType.Int32).Value = pizza.Quantity;
                        itemCommand.Parameters.Add("@pr", MySqlDbType.Double).Value = pizza.Price;

                        itemCommand.ExecuteNonQuery();
                    }

                    connect.closeConnection();
                    return true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    connect.closeConnection();
                    return false;
                }
            }
        }
    }
}
        

    //    internal class Order
    //    {
    //        CONNECT connect = new CONNECT();

    //        // SAVE ORDER
    //        public bool SaveOrder
    //        (
    //            Customer customer,
    //            string paymentMethod
    //        )
    //        {
    //            try
    //            {
    //                connect.openConnection();

    //                // =========================
    //                // INSERT CUSTOMER
    //                // =========================

    //                MySqlCommand customerCommand =
    //                    new MySqlCommand();

    //                customerCommand.Connection =
    //                    connect.getConnection();

    //                customerCommand.CommandText =
    //                "INSERT INTO orders(`first_name`, `last_name`, `address`, `phone`, `phone``email`) VALUES ('@fn','@ln','@ad','@ph','@em')";

    //                customerCommand.Parameters.Add("@fn",
    //                    MySqlDbType.VarChar).Value =
    //                    customer.FirstName;

    //                customerCommand.Parameters.Add("@ln",
    //                    MySqlDbType.VarChar).Value =
    //                    customer.LastName;

    //                customerCommand.Parameters.Add("@ad",
    //                    MySqlDbType.VarChar).Value =
    //                    customer.Address;

    //                customerCommand.Parameters.Add("@ph",
    //                    MySqlDbType.VarChar).Value =
    //                    customer.Phone;

    //                customerCommand.Parameters.Add("@em",
    //                    MySqlDbType.VarChar).Value =
    //                    customer.Email;

    //                customerCommand.ExecuteNonQuery();

    //                int customerID =
    //                    Convert.ToInt32(customerCommand.LastInsertedId);

    //                // =========================
    //                // TOTAL PRICE
    //                // =========================

    //                double totalPrice = 0;

    //                foreach (Pizza pizza in Cart.cartItems)
    //                {
    //                    totalPrice += pizza.Price;
    //                }

    //                // =========================
    //                // INSERT ORDER
    //                // =========================

    //                MySqlCommand orderCommand =
    //                    new MySqlCommand();

    //                orderCommand.Connection =
    //                    connect.getConnection();

    //                orderCommand.CommandText =
    //                "INSERT INTO orders(`customer_id`, `total_price`, `payment_method`, `order_date`) VALUES ('@ci','@tp','@pm','@od')";

    //                orderCommand.Parameters.Add("@cid",
    //                    MySqlDbType.Int32).Value =
    //                    customerID;

    //                orderCommand.Parameters.Add("@tp",
    //                    MySqlDbType.Double).Value =
    //                    totalPrice;

    //                orderCommand.Parameters.Add("@pm",
    //                    MySqlDbType.VarChar).Value =
    //                    paymentMethod;

    //                orderCommand.Parameters.Add("@od",
    //                    MySqlDbType.DateTime).Value =
    //                    DateTime.Now;

    //                orderCommand.ExecuteNonQuery();

    //                int orderID =
    //                    Convert.ToInt32(orderCommand.LastInsertedId);

    //                // =========================
    //                // INSERT ORDER ITEMS
    //                // =========================

    //                foreach (Pizza pizza in Cart.cartItems)
    //                {
    //                    MySqlCommand itemCommand =
    //                        new MySqlCommand();

    //                    itemCommand.Connection =
    //                        connect.getConnection();

    //                    itemCommand.CommandText =
    //                    "INSERT INTO order_items(`order_id`, `pizza_name`, `pizza_size`, `toppings`, `quantity`, `item_price`) VALUES ('@oid','@pn','@ps','@tp','@qt','@pr')";

    //                    itemCommand.Parameters.Add("@oid",
    //                        MySqlDbType.Int32).Value =
    //                        orderID;

    //                    itemCommand.Parameters.Add("@pn",
    //                        MySqlDbType.VarChar).Value =
    //                        pizza.Name;
    //                    itemCommand.Parameters.Add("@ps",
    //                        MySqlDbType.VarChar).Value =
    //                        pizza.Size;

    //                    itemCommand.Parameters.Add("@tp",
    //                        MySqlDbType.Text).Value =
    //                        string.Join(",", pizza.Toppings);

    //                    itemCommand.Parameters.Add("@qt",
    //                        MySqlDbType.Int32).Value =
    //                        pizza.Quantity;

    //                    itemCommand.Parameters.Add("@pr",
    //                        MySqlDbType.Double).Value =
    //                        pizza.Price;

    //                    itemCommand.ExecuteNonQuery();
    //                }

    //                connect.closeConnection();

    //                return true;
    //            }
    //            catch (Exception ex)
    //            {
    //                MessageBox.Show(ex.Message);

    //                connect.closeConnection();

    //                return false;
    //            }
    //        }
    //    //}



