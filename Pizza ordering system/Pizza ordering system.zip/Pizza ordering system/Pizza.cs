﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizza_ordering_system
{
    internal class Pizza
    {
        public string Name { get; set; }
        public string Size { get; set; }
        public List<string> Toppings { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }

    }
}
