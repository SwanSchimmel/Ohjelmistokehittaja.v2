﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_ordering_system
{
    public partial class PaymentForm : Form
    {
        int orderId;
        Customer customer = new Customer();

        public PaymentForm()
        {
        }

        public PaymentForm(int orderId)
        {
            InitializeComponent();
            this.orderId = orderId;
        }

        private void buttonPay_Click(object sender, EventArgs e)
        {
            customer.FirstName = textBoxFirstName.Text;
            customer.LastName = textBoxLastName.Text;
            customer.Address = textBoxAddress.Text;
            //customer.Phone = textBoxPhone.Text;
            //customer.Email = textBoxEmail.Text;
            customer.PaymentMethod = comboBoxPayment.Text;

            MessageBox.Show("Payment Success");

            ConfirmForm confirmForm = new ConfirmForm();
            confirmForm.Show();
        }
    }
}
